# QA Results — SA Calculator v98.38

- Automated regression tests: **273 passed, 0 failed, 0 skipped**.
- Node mixed-module reparsing warnings: none; ESM tests are `.mjs`, CommonJS tests remain `.js`.
- JavaScript syntax checks: passed for runtime, service worker, server, web-bundle builder and native branding patch.
- Android web bundle: generated; v98.38 stylesheet present and byte-identical to source.
- Release identity: `1.98.38-v98.38`; Android versionCode `1098038`.
- Active workflow, downloadable YAML and maintained reference workflow copies: byte-identical.
- All 18 source-defined screen IDs retained.
- YAML syntax and ZIP integrity: verified.

## Not certified here

GitHub-hosted APK generation and physical-device screenshots, touch/IME behavior, performance, memory, battery and long-session stability were not executed. Therefore zero-lag/zero-bug claims are not made.
