# SA Calculator v98.54 QA results

## Passed locally
- 340/340 automated regression tests (`npm test`).
- `npm run build:web`: 30 required assets verified; 18 CSS source layers consolidated.
- JavaScript syntax checks covered by regression suite.
- PostCSS parse: `rebuild-v98.54.css`, consolidated `assets/css/app.css`, and generated `www/assets/css/app.css` all parse.
- GitHub Actions YAML parses successfully.
- Source and generated web bundle contain the wave and dedicated Home logo SVG assets.
- Source and generated consolidated CSS are byte-identical.
- Workflow copies are byte-identical.
- Old `rebuild-v98.53.css` file is absent from source and generated bundle.
- ZIP archive integrity is checked at packaging time.

## Not yet verified
- Hosted GitHub Actions Android Gradle build / APK output.
- Installation and runtime behavior on a physical Android phone.
- Exact device screenshot match across multiple screen sizes and Android font scales.
- Measured frame-time, memory and long-session performance.

No claim of completely bug-free or zero-lag physical-device behavior is made until those checks complete.
