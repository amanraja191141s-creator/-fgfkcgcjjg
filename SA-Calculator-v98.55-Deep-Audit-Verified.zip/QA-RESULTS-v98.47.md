# QA results — v98.47

- Automated tests: **311 passed, 0 failed**.
- JavaScript syntax: passed via the Node test runner's source parsing checks.
- Android web bundle: regenerated successfully; 23 required assets verified and 13 CSS source layers consolidated into one production `app.css` request.
- Standalone Scientific screen: present and included in the Android bundle/cache.
- Basic calculator markup: no scientific shortcut, scientific function controls, angle toggle or scientific memory controls.
- Scientific UI: independent expression/result/angle/memory/history/ANS state and storage keys.
- Release identity: `1.98.47-v98.47`; Android versionCode `1098047`.
- ZIP and YAML checks are recorded in `RELEASE-VERIFICATION-v98.47.md`.

Not tested in this workspace: hosted Android APK compilation, physical-device installation, real-device screenshot comparison, touch latency, frame rate, memory and battery.
