# Release verification — v98.47

- Package version: `1.98.47-v98.47`
- Manifest version: `1.98.47-v98.47`
- Runtime version: `1.98.47-v98.47`
- Android versionCode: `1098047`
- Service Worker cache: `sa-calculator-v98-47-isolated-scientific-screen`
- Workflow: `.github/workflows/main.yml`
- Downloadable workflow copy: `SA-Calculator-v98.47-Android-Workflow.yml`
- Regression tests: 311 passed, 0 failed.
- Android web bundle: generated; 23 required assets verified; 13 CSS layers consolidated.
- Source ZIP: checked with `unzip -t` after packaging.
- YAML: parsed successfully after packaging.

A hosted APK build and physical Android installation/visual/performance verification remain outstanding.
