# v98.55 micro-level keypad audit

## Root cause
The previous Home keypad used `flex:1` with five `1fr` rows. This made button height depend on leftover vertical space rather than the width-based proportions in the approved reference. On narrower phone viewports with the same portrait aspect ratio, buttons could become too tall relative to their width. The previous layout also retained a 14px bottom keypad inset that is absent from the supplied reference, and the number glyph sizing was based on `vw` rather than the actual app container.

## Correction
- Removed `assets/css/rebuild-v98.54.css` and its reference from `index.html` and `scripts/prepare-android-web.mjs`.
- Added one authoritative `assets/css/rebuild-v98.55.css` Home layer.
- Set the row height to `20.55cqw` and keypad block size to `102.75cqw + 33px` (standard) / `102.75cqw + 28px` (compact), with five equal tracks.
- Set gap to `clamp(5px, 1.5cqw, 6.5px)`, side inset to `clamp(7px, 1.8cqw, 8px)`, top inset to `1.8cqw`, and bottom inset to zero.
- Set radius to `4.5cqw`; number/utility/AC/operator/equal text scales to 8.4/8.6/9.5/10.2/10.5cqw with clamps.
- Kept `min-width` and `min-height` at 48px for the actual button hitboxes.
- Added older-WebView fallback, short-height and landscape behavior.

## Estimated reference geometry
Reference image: 852×1846 px; calibrated at 2 image pixels per CSS pixel. At 426 CSS px app width, target key width is approximately 98px and height approximately 87.5px. At 354 CSS px app width, target key width is approximately 81px and height approximately 72.7px. This maintains the same approximate 1.12:1 width-to-height ratio instead of stretching vertically.
