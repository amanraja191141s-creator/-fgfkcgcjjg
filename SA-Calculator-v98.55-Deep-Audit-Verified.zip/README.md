# SA Calculator v98.55 — Reference-Proportional Keypad Rebuild

This release replaces the v98.54 Home keypad sizing layer with a width-derived 4×5 geometry calibrated from the supplied Neon Blue SA Calculator reference.

## Included
- Full SA Calculator source and Android Capacitor project configuration.
- One authoritative Home stylesheet: `assets/css/rebuild-v98.55.css` (the v98.54 Home layer is removed from the active build chain and source tree).
- Five equal keypad rows sized against the app container width, not stretched to consume leftover screen height.
- Width-scaled key typography, radius and spacing; 48px minimum key dimensions; compact/short/landscape fallbacks.
- Preserved 19 original `data-calc` handlers and four-column/five-row keypad order.
- Android GitHub Actions workflow and generated offline `www/` bundle.

## Release identity
- Package: `1.98.55-v98.55`
- Android versionCode: `1098055`
- Offline cache: `sa-calculator-v98-55-reference-proportional-keypad-v9855`

## Build and verification
- `npm test`
- `npm run build:web`
- GitHub Actions workflow: `.github/workflows/main.yml`

Physical-device screenshot matching, APK installation and device performance measurements still require a real Android device/build runner.
