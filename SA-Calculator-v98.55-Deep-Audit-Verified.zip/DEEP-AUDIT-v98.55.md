# SA Calculator v98.55 — Deep Source, UI, Architecture & Android Workflow Audit

Audit date: 19 November 2026
Audited inputs:
- `SA-Calculator-v98.55-Reference-Proportional-Keypad.zip`
- `SA-Calculator-v98.55-Android-Workflow.yml`

## Executive result

The supplied archive is internally consistent and the existing automated suite passes. The supplied workflow's required source files and generated Android web assets are present. The project is **not certified bug-free or lag-free**: a physical Android installation, hosted Gradle build, visual screenshot comparison, accessibility inspection and performance profiling were not run in this environment.

## Reproducible checks performed against the extracted ZIP

| Check | Result |
|---|---|
| ZIP extraction / integrity | Passed |
| `npm test` | 341 passed, 0 failed |
| `npm run build:web` | Passed; 30 required runtime assets verified; 18 CSS source layers consolidated |
| JavaScript syntax | 8 source/runtime/build files passed `node --check` |
| Workflow required source files | 32 checked, 0 missing |
| Generated bundle required assets | 23 checked, 0 missing |
| Root and `www` HTML/manifest/service worker | Byte-identical |
| Workflow root copy and `.github/workflows/main.yml` | Byte-identical |
| Package/runtime/manifest/workflow version | `1.98.55-v98.55` aligned |
| Physical Android / APK | Not run; no Android SDK or `android/` Gradle project in this local source archive |
| Real-device latency, memory, touch and screenshot tests | Not run |

## Source-grounded architecture findings

1. `assets/js/app.js` is 366,137 bytes and contains the primary app runtime. This is a large monolithic surface; the passing tests do not establish module isolation or low runtime cost.
2. `assets/js/localization.js` is 192,859 bytes. Locale loading and translation lookup should be profiled before any lazy-loading change because current UI code may depend on eager globals.
3. `assets/css/app-base.css` is 657,161 bytes. The build consolidates 18 ordered CSS layers into `assets/css/app.css` (845,225 bytes). This is a functional compatibility stack, not yet a clean token/component CSS architecture.
4. The archive includes both source assets and a generated `www/` Android web bundle. These are byte-identical for the key HTML, manifest and service-worker files checked; build output should remain generated, not manually edited.
5. `service-worker.js` uses a versioned cache and explicitly avoids caching `/api/` responses. This is the correct direction for avoiding stale currency API payloads.
6. The v98.55 keypad uses width-relative geometry and keeps the 19 original `data-calc` hooks. Its geometry tests cover 426px and 354px reference widths; they do not cover every Android WebView, font-scale, split-screen or landscape combination.
7. The workflow selects the exact `1.98.55-v98.55` package and checks the APK's package version/versionCode. The workflow is internally aligned with the supplied ZIP.

## 26-app benchmark scope

The documented benchmark includes Google Calculator, Samsung Calculator, ClevCalc, HiPER, RealCalc, RealCalc Plus, Desmos Scientific, Desmos Graphing, GeoGebra Scientific, GeoGebra Graphing, GeoGebra CAS, GeoGebra Suite, Calculator Plus with History, Calculator Plus, CALCU, Calculator++, Fossify Calculator, MobiCalc, CalcTastic, TechCalc, Photomath, Wolfram|Alpha, Calculator M3, OpenCalc, Unitto and NumerIQ, plus the Fossify offline/privacy workflow as a separate benchmark dimension. See `RESEARCH-20-PLUS-ANDROID-CALCULATOR-APPS-v98.41.md` for the feature matrix and source links.

This is desk research from current app listings and comparison sources. It is not a claim that 26 apps were installed and benchmarked on one device.

## UI and behavior assessment

The supplied reference establishes the Home calculator composition: dark navy background, blue wave accent, expression/result display without a surrounding result card, 4-column × 5-row keypad, zero spanning two columns, and five bottom destinations. Existing v98.55 automated tests verify those structural rules and the original calculation hooks.

The existing release also has distinct screens for Scientific, Tools, History, Favorites, Settings and converters. Those systems should not be removed until their state, persistence, calculation formulas and navigation paths have dedicated replacement tests.

## Required next engineering phase for a true full replacement

A true UI/architecture replacement is larger than a safe one-line patch. The next release should be treated as a controlled migration:

- Establish design tokens and component primitives first; remove historical CSS layers only after visual parity tests exist.
- Split the runtime into explicit modules: app shell/navigation, basic calculator engine, scientific engine, formatting, history/persistence, tool registry, currency data, localization and settings/theme.
- Keep a single typed/validated state contract and a single navigation stack; avoid duplicate screen-specific state stores.
- Give each calculator/tool a capability manifest so unsupported controls cannot appear as active actions.
- Add numerical golden tests for every formula and boundary; add property tests for currency ratios, unit conversions, date boundaries and scientific notation.
- Add browser-level interaction tests for touch, keyboard, focus, Android Back, safe areas, font scaling and screen rotation.
- Measure cold start, first interaction, keypad input latency, long-session memory and layout shift on a real low/mid-range Android device.
- Generate the Android web bundle from source and build the APK in GitHub Actions; verify install/launch and capture screenshots before release.

## Release honesty

No source runtime or visual redesign was silently substituted in this audit package. The supplied v98.55 application source remains intact because all 341 existing tests pass and a wholesale rewrite without equivalent behavioral tests would risk removing working calculator features. This package adds the reproducible audit and expanded benchmark record; it must not be described as the completed full architecture/UI replacement or as a physically tested zero-lag APK.
