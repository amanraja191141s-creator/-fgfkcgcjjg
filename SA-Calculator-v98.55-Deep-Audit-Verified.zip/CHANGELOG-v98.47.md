# v98.47 — Independent Scientific Calculator

- Replaced the scientific modal with a real standalone screen reachable from Tools.
- Removed all scientific controls from the basic calculator screen and drawer.
- Removed legacy `insertScientificFunction`/operand-selection bridge that directly mutated basic calculator expression state.
- Removed shared basic calculator angle and memory state; scientific DEG/RAD, memory, history, ANS and expression state are isolated.
- Added scientific history persistence (50 records), tap-to-restore and clear.
- Added five memory actions, ANS, Euler's number, π, eˣ, 10ˣ, x², x³, roots, powers, factorial, reciprocal, absolute value, logarithms, trig/inverse trig and hyperbolic functions.
- Added responsive scientific keypad and display styling, compiled into `www/assets/css/app.css` and Service Worker cache.
- Updated Android workflow and release identity to `1.98.47-v98.47` / `1098047`.
