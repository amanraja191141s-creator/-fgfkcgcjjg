# QA Results — v98.50

| Check | Result |
|---|---|
| Automated regression tests | PASS — 328 passed, 0 failed |
| JavaScript syntax | PASS — all 8 app/build entry points |
| YAML syntax | PASS — GitHub Actions workflow parsed |
| Android web bundle | PASS — 26 required inputs verified; 16 CSS layers consolidated |
| Scientific keypad inventory | PASS — 18 primary functions, 5 additional functions + ANS, 20 numeric/operator keys |
| Scientific layout | PASS — 6-column function bank, 5-column × 4-row numeric keypad |
| Secondary function legends | PASS — 18 supported primary function legends |
| Basic keypad touch target | PASS — minimum 48px retained; no transform-based hit-area shrinking |
| Release identity | PASS — 1.98.50-v98.50 / 1098050 |
| Workflow copies | PASS — root alias and `.github/workflows/main.yml` identical |
| Service worker cache | PASS — new v98.50 namespace |
| ZIP integrity | PASS — verified after packaging |

Android SDK/Gradle hosted APK build and physical-device screenshot/touch/performance validation remain pending.
